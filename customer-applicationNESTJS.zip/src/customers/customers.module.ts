import { Module, MiddlewareConsumer, RequestMethod, NestModule } from '@nestjs/common';
import { CustomersController } from './controller/customers/customers.controller';
import { CustomersService } from './services/customers/customers.service';
import { ValidCustomerMiddleware } from './middlewares/validate-customer.middleware';
import { ValidateCustomerAccountMiddleware } from './middlewares/validate-customer-account.middleware';

@Module({
  controllers: [CustomersController],
  providers: [CustomersService]
})
export class CustomersModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(ValidCustomerMiddleware,ValidateCustomerAccountMiddleware)
    .exclude({
      path: '/customers/all',
      method: RequestMethod.GET,
    })
    .forRoutes(CustomersController);
  }
}
