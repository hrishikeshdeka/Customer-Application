import {
  Controller,
  Get,
  Post,
  Delete,
  Req,
  Res,
  Param,
  ParseIntPipe,
  HttpException,
  HttpStatus,
  Body,
  ValidationPipe,
  UsePipes
} from '@nestjs/common';
import { CustomersService } from 'src/customers/services/customers/customers.service';
import { Request, Response } from 'express';
import { CreateCustomerDto } from 'src/customers/dtos/CreateCustomer.dto';

@Controller('customers')
export class CustomersController {
  constructor(private customersService: CustomersService) {}
  // @Get('/:id')
  // getCustomerById(
  //     @Param('id',ParseIntPipe) id:number,
  //     @Req() req:Request,
  //     @Res() res:Response){
  //         const customer= this.customersService.findCustomerById(id);
  //    if(customer){
  //     res.send(customer);
  //    }else{
  //     res.status(400).send({msg:'Customer not Found!'});
  //    }
  // }

  @Get('/search/:id')
  searchCustomerById(@Param('id', ParseIntPipe) id: number) {
    const customer = this.customersService.findCustomerById(id);
    if (customer) return customer;
    else throw new HttpException('customer Not Found!', HttpStatus.BAD_REQUEST);
  }

  @Get('all')
  getAllCustomers() {
    return this.customersService.getCustomers();
  }

  @Post('create')
  @UsePipes(ValidationPipe)
  createCustomer(@Body() createCustomerDto: CreateCustomerDto) {
    console.log(createCustomerDto);
    this.customersService.createCustomer(createCustomerDto);
  }
}
