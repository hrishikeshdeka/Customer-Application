import { Injectable } from '@nestjs/common';
import { CreateCustomerDto } from 'src/customers/dtos/CreateCustomer.dto';
import { Customer } from 'src/customers/types/Customer';

@Injectable()
export class CustomersService {

    private customers:Customer[]= [{
        id:1,
        email:'danny@gmail.com',
        name:'Danny'
    },
    {
        id:2,
        email:'hrishikesh@gmail.com',
        name:'Hrishikesh'
       
    },{ 
        id:3,
        email:'silva@gmail.com',
        name:'Silva'
       
    }
]


    findCustomerById(id:number){
        return this.customers.find((customer)=> 
        customer.id == id);

    }
    getCustomers(){
        return this.customers;
    }
    createCustomer(customerDto : CreateCustomerDto){
        this.customers.push(customerDto);
    }
}
