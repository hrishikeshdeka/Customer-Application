import { User } from "./User";

const entities=[User];

export {User};
export default entities;