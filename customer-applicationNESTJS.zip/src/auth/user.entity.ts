import { MinLength, minLength } from "class-validator";
import { Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class User{

    
    @PrimaryGeneratedColumn()
    id:string;

    @MinLength(3)
    @Column({unique:true})
    username: string;

    @MinLength(4, {message:'password length should be atleast 4'})
    @Column()
    password: string;

}