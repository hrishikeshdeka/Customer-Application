import { Injectable, UnauthorizedException } from '@nestjs/common';
import { Repository } from 'typeorm';
import { User } from './user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import * as bcrypt from 'bcrypt';
import { JwtPayload } from './jwt-payload.interface';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {

    constructor(
        @InjectRepository(User)
        private userRepo: Repository<User>,
        private jwtService: JwtService)
        {}


    async signUp(user: User): Promise<User>{
        const {username, password} = user;

        const salt = await bcrypt.genSalt();
        const hashPwd = await bcrypt.hash(password,salt);

        const usr = this.userRepo.create({username,password:hashPwd});
        await this.userRepo.save(usr);

        return usr;
    }    

    async signIn(user: User): Promise<{accessToken:string}>{
        const {username, password} = user;
        const usr = await this.userRepo.findOne({where:{username}});

        if(usr && (await bcrypt.compare(password,usr.password))){
            const payload: JwtPayload = {username};
            const accessToken: string = await this.jwtService.sign(payload);
           // return 'Logged In';
            return {accessToken};
           
        }
        else{
            throw new UnauthorizedException("Invalid Credentials");
        }

    }
}
